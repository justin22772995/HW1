#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int n, s, c;
	printf("number\t\tsquare\t\tcube\n");
	for (n = 0; n <= 10; n++)
	{
		s = n * n;
		c = n * s;
		printf("%d\t\t%d\t\t%d\n", n, s, c);
	}
	system("pause");
	return 0;
}