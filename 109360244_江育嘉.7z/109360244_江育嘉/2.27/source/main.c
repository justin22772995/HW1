#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int a, b, c;
	printf("    *\n");
	printf("   ***\n");
	printf("  *****\n");
	printf(" *******\n");
	printf("*********\n");

	printf("    *\n   ***\n  *****\n *******\n*********\n");
	system("pause");
		return 0;
}
