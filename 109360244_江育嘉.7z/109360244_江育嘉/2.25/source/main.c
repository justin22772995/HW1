#include <stdio.h>
#include<stdlib.h>

int main(void)
{

	printf("   CCCCC\n");
	printf(" C       C\n");
	printf("C         C\n");
	printf("C         C\n");
	printf(" C       C\n\n");
	printf("        Y\n");
	printf("      Y\n");
	printf("YYYYY\n");
	printf("      Y\n");
	printf("        Y\n\n");
	printf("   JJ\n");
	printf(" J\n");
	printf("J\n");
	printf(" J\n");
	printf("   JJJJJJJ\n");







}