#include <stdio.h>
#include <stdlib.h>

float a, b, c;

int main(void)
{
	printf("�п�J����(cm)�G");
	scanf_s("%f", &a);
	printf("�п�J�魫(kg)�G");
	scanf_s("%f", &b);

	c = b / ((a / 100) * (a / 100));

	if (c < 18.5)
	{
		printf("Your BMI�G%.2f Under less\n", c);
	}
	else if ((c >= 18.5) && (c <= 24.9))
	{
		printf("Your BMI�G%.2f Normal\n", c);
	}
	else if ((c >= 25) && (c <= 29.9))
	{
		printf("Your BMI�G%.2f Overweight\n", c);
	}
	else
	{
		printf("Your BMI�G%.2f Obese\n", c);
	}
	system("pause");
	return 0;
}