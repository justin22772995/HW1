#include <stdio.h>
#include<stdlib.h>

int a, b, c,d;

int main(void)
{
	printf("�п�J�T�Ӿ�ơG\n");
	scanf_s("%d%d%d", &a, &b, &c);
	if (a > b)
	{
		d = a;
		a = b;
		b = d;
	}
	if (b > c)
	{
		d = b;
		b = c;
		c = d;
	}
	if (a > b)
	{
		d = a;
		a = b;
		b = d;
	}
	printf("largest  number is %d\n", c);
	printf("smallest number is %d\n",a);
	system("pause");
	return 0;
}